<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Estagio extends Model
{
    protected $fillable = ['aluno_id', 'empresa_concedente_id', 'professor_orientador_id',
                           'supervisor_empresa_id', 'data_inicio', 'data_termino',
                           'carga_horaria_diaria', 'bolsa_auxilio', 'status'];

    protected $casts = [
        'data_inicio' => 'date',
        'data_termino' => 'date',
        'bolsa_auxilio' => 'decimal:2',
    ];

    public function aluno()       { return $this->belongsTo(Aluno::class); }
    public function empresa()     { return $this->belongsTo(EmpresaConcedente::class, 'empresa_concedente_id'); }
    public function orientador()  { return $this->belongsTo(ProfessorOrientador::class, 'professor_orientador_id'); }
    public function supervisor()  { return $this->belongsTo(SupervisorEmpresa::class, 'supervisor_empresa_id'); }

    public function apolice()     { return $this->hasOne(ApoliceSeguro::class); }
    public function plano()       { return $this->hasOne(PlanoEstagio::class); }
    public function salubridade() { return $this->hasOne(DeclaracaoSalubridade::class); }
    public function relatorio()   { return $this->hasOne(RelatorioEstagio::class); }
    public function frequencias() { return $this->hasMany(DiarioFrequencia::class); }
    public function avaliacoes()  { return $this->hasMany(AvaliacaoEstagio::class); }

    public function horasCumpridas(): float
    {
        return $this->frequencias()->where('assinado_supervisor', true)->sum('horas_diarias');
    }
}