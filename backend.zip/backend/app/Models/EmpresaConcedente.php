<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EmpresaConcedente extends Model
{
    protected $table = 'empresas_concedentes';
    protected $fillable = ['cnpj', 'razao_social', 'endereco_completo',
                           'representante_legal', 'status_convenio'];

    public function supervisores() { return $this->hasMany(SupervisorEmpresa::class); }
    public function estagios()     { return $this->hasMany(Estagio::class); }

    public function convenioAtivo(): bool
    {
        return $this->status_convenio === 'ativo';
    }
}
