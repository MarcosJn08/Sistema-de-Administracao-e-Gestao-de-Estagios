<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class Usuario extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;
    protected $table = 'usuarios';
    protected $fillable = ['nome', 'email', 'password', 'perfil', 'status'];
    protected $hidden = ['password', 'remember_token'];
    protected $casts = ['password' => 'hashed'];

    public function aluno()      { return $this->hasOne(Aluno::class); }
    public function professor()  { return $this->hasOne(ProfessorOrientador::class); }

    public function temPerfil(string ...$perfis): bool
    {
        return in_array($this->perfil, $perfis);
    }
}
