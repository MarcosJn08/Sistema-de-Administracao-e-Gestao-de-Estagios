<?php

namespace Database\Seeders;

use App\Models\Curso;
use App\Models\Usuario;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    public function run(): void
    {
        Usuario::create([
            'nome' => 'Administrador',
            'email' => 'admin@sage.test',
            'password' => 'admin123', // o cast 'hashed' do Model já criptografa
            'perfil' => 'admin',
        ]);

        $curso = Curso::create([
            'nome' => 'Sistemas de Informação',
            'codigo' => 'SI',
            'carga_horaria_estagio' => 400,
        ]);

        $curso->turmas()->create([
            'nome' => 'SI 2026.1',
            'ano' => 2026,
            'semestre' => 1,
            'turno' => 'noturno',
        ]);
    }
}