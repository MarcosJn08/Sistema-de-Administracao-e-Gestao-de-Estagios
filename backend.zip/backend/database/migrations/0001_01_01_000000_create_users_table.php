<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
{
    Schema::create('usuarios', function (Blueprint $table) {
        $table->id();
        $table->string('nome');
        $table->string('email')->unique();
        $table->timestamp('email_verified_at')->nullable();
        $table->string('password');
        $table->enum('perfil', ['admin', 'coordenador', 'aluno', 'professor', 'supervisor']);
        $table->enum('status', ['ativo', 'inativo'])->default('ativo');
        $table->rememberToken();
        $table->timestamps();
    });

    // password_reset_tokens e sessions ficam exatamente como estão

    Schema::create('password_reset_tokens', function (Blueprint $table) {
        $table->string('email')->primary();
        $table->string('token');
        $table->timestamp('created_at')->nullable();
    });

    Schema::create('sessions', function (Blueprint $table) {
        $table->string('id')->primary();
        $table->foreignId('user_id')->nullable()->index();
        $table->string('ip_address', 45)->nullable();
        $table->text('user_agent')->nullable();
        $table->longText('payload');
        $table->integer('last_activity')->index();
    });
}

    public function down(): void
{
    Schema::dropIfExists('usuarios');
    Schema::dropIfExists('password_reset_tokens');
    Schema::dropIfExists('sessions');
}
};
