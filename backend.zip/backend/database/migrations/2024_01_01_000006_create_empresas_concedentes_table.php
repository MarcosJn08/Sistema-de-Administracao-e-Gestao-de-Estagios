<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('empresas_concedentes', function (Blueprint $table) {
    $table->id();
    $table->string('cnpj', 18)->unique();
    $table->string('razao_social');
    $table->string('endereco_completo');
    $table->string('representante_legal');
    $table->enum('status_convenio', ['pendente', 'ativo', 'vencido', 'cancelado'])->default('pendente');
    $table->timestamps();
});
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('empresa_concedentes');
    }
};
