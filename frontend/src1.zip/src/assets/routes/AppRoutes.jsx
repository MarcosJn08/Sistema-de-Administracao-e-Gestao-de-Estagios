import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import LandingPage from '../../pages/LandingPage.jsx';
import DashboardAluno from '../../pages/DashboardAluno.jsx';
import VitrineVagas from '../../pages/VitrineVagas.jsx';
import CentralDocumentos from '../../pages/CentralDocumentos.jsx';
import Login from '../../pages/Login.jsx';
import DadosEmpresa from '../../pages/Cadastro/Dados.jsx';
import DocumentosEmpresa from '../../pages/Cadastro/Documentos.jsx';
import ConfirmacaoEmpresa from '../../pages/Cadastro/Confirmacao.jsx';
import TelaEstagio from '../../pages/TelaEstagio.jsx';
import DashboardDiretor from '../../pages/DashboardDiretor.jsx';
import DashboardEmpresa from '../../pages/DashboardEmpresa.jsx';
import EnviarDocumento from "../../pages/EnviarDocumento/EnviarDocumento.jsx";

function AppRoutes() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Navigate to="/sage" replace />} />
        <Route path="/sage" element={<LandingPage />} />
        
        <Route path="/sage/aluno" element={<DashboardAluno />} />
        <Route path="/sage/diretor" element={<DashboardDiretor />} />
        <Route path="/sage/empresa" element={<DashboardEmpresa />} />
        <Route path="/sage/vagas" element={<VitrineVagas />} />
        <Route path="/sage/documentos" element={<CentralDocumentos />} />
        <Route path="/sage/login" element={<Login />} />

        <Route path="/sage/cadastro/empresa" element={<DadosEmpresa />} />
        <Route path="/sage/cadastro/documento" element={<DocumentosEmpresa />} />
        <Route path="/sage/cadastro/confirmacao" element={<ConfirmacaoEmpresa />} />
        <Route path="/sage/estagio" element={<TelaEstagio />} />
        <Route path="*" element={<Navigate to="/sage" replace />} />
        <Route path="/sage/enviar-documento" element={<EnviarDocumento />} />
      </Routes>
    </BrowserRouter>
  );
}

export default AppRoutes;
