import { useState } from 'react';
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import Offcanvas from 'react-bootstrap/Offcanvas';
import Button from '../Button.jsx';
import LogoBranca from '../../assets/LogoBranca.png';

function Header({
  pagina01 = 'Dashboard',
  pagina02 = 'Alunos',
  pagina03 = 'Orientadores',
  pagina04 = 'Empresa',
  pagina05 = 'Estágios',
  paginaAtiva,
  usuario,
  customLinks,
  somenteInicio = false,
}) {
  const [expanded, setExpanded] = useState(false);
  const closeMenu = () => setExpanded(false);

  const isDashboard = Boolean(usuario);

  const landingLinks = [
    [pagina01, '#inicio'],
    [pagina02, '#perfis'],
    [pagina03, '#vagas'],
    [pagina04, '#empresas'],
    [pagina05, '#contato'],
  ];

  const dashboardLinks = [
    [pagina01, '/sage/aluno'],
    [pagina02, '/sage/alunos'],
    [pagina03, '/sage/orientadores'],
    [pagina04, '/sage/empresas'],
    [pagina05, '/sage/estagios'],
  ];

  const cadastroLinks = [
    ['Início', '/sage'],
  ];

  const links = customLinks || (somenteInicio ? cadastroLinks : isDashboard ? dashboardLinks : landingLinks);

  return (
    <Navbar
      expand="lg"
      expanded={expanded}
      onToggle={setExpanded}
      className="dark-green header"
      data-bs-theme="dark"
      aria-label="Navegação principal"
    >
      <Container fluid className="sage-edge-container">
        <Navbar.Brand href="/sage" onClick={closeMenu}>
          <img src={LogoBranca} className="logo" alt="SAGE — início" width="60" height="60" />
        </Navbar.Brand>
        <Navbar.Toggle
          aria-controls="offcanvasNavbar"
          aria-expanded={expanded}
          label="Abrir menu de navegação"
        />
        <Navbar.Offcanvas
          id="offcanvasNavbar"
          placement="end"
          restoreFocusOptions={{ preventScroll: true }}
          onHide={closeMenu}
          className="sage-menu"
          aria-labelledby="menu-title"
        >
          <Offcanvas.Header closeButton closeVariant="white" closeLabel="Fechar menu">
            <Offcanvas.Title id="menu-title">Menu SAGE</Offcanvas.Title>
          </Offcanvas.Header>
          <Offcanvas.Body>
            <Nav className="menu-central">
              {links.map(([label, href]) => (
                <Nav.Link
                  key={href}
                  href={href}
                  onClick={closeMenu}
                  className={paginaAtiva === label ? 'nav-link-active' : ''}
                >
                  {label}
                </Nav.Link>
              ))}
            </Nav>
            {!somenteInicio && (
              <div className="botao-login">
                {isDashboard ? (
                  <div className="d-flex align-items-center gap-3">
                    <div className="perfil-usuario-header">
                      <div className="avatar-usuario-header">
                        <span>{usuario.nome ? usuario.nome.charAt(0).toUpperCase() : 'A'}</span>
                      </div>
                      <span className="nome-usuario-header">
                        {usuario.nome ? usuario.nome.split(' ')[0] : 'Aluno'}
                      </span>
                    </div>
                    <Button texto="Sair" tipo="botao-texto-branco" href="/sage/login" />
                  </div>
                ) : (
                  <>
                  </>
                )}
              </div>
            )}
          </Offcanvas.Body>
        </Navbar.Offcanvas>
      </Container>
    </Navbar>
  );
}

export default Header;
