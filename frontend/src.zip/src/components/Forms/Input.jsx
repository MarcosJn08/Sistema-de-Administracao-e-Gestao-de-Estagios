import "./Input.css";
import Form from "react-bootstrap/Form";

function Input({ id, titulo, tipo, texto }) {
  return (
    <Form >
      <Form.Group className="mb-3" controlId={id} >
        <Form.Label>{titulo}</Form.Label  >
        <Form.Control type={tipo} placeholder={texto} className="input" />
      </Form.Group>
    </Form>
  );
}

export default Input;
