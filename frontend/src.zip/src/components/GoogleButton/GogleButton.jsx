import React from 'react';
import './GogleButton.css';

const GoogleButton = ({ onClick }) => {
  return (
    <button className="google-login-btn" onClick={onClick}>
      <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" alt="Google logo" />
      <span>Entrar com Google</span>
    </button>
  );
};

export default GoogleButton;   