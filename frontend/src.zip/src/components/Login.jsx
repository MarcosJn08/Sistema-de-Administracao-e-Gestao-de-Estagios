import Image from "react-bootstrap/Image";
import "../App.css";

import Input from "./Forms/Input.jsx";
import GoogleButton from "./GoogleButton/GogleButton.jsx";
import Button from "./Button/Button.jsx";
import ImgLogin from "../assets/Login.png";

function Login() {
  return (
    <div className="login-container">
      <div className="login-image">
        <Image src={ImgLogin} />
      </div>

      <div className="login-content">
        <h1>Bem Vindo ao SAGE </h1>
        <p>Sistema de Administração e Gestão de Estágio</p>
        <Input
          id="email"
          titulo="Email"
          tipo="email"
          texto="Digite seu Email"
        />
        <Input
          id="senha"
          titulo="Senha"
          tipo="password"
          texto="Digite sua senha"
        />
        
        <Button texto="Fazer Login" tipo="botao-com-fundo" />
        <GoogleButton />
      </div>
    </div>
  );
}

export default Login;
