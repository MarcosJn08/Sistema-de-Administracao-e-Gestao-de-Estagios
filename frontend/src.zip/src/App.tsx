import { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import Navbar from './components/Header.jsx';
import Login from './components/Login.jsx';

function App() {
  const [count, setCount] = useState(0)

  return (
    <Login />
  )
}

export default App
