import React from "react";
import Box from "@mui/material/Box";

function Input({ id, titulo, tipo, texto, value, onChange }) {
  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        width: "100%",
        marginBottom: "16px",
      }}
    >
      <Box
        component="label"
        htmlFor={id}
        sx={{
          alignSelf: "flex-start",
          marginBottom: "6px",
          fontSize: "14px",
          fontWeight: 500,
          color: "#333",
        }}
      >
        {titulo}
      </Box>

      <Box
        component="input"
        id={id}
        type={tipo}
        placeholder={texto}
        value={value}
        onChange={onChange}
        sx={{
          width: "100%",
          boxSizing: "border-box",
          padding: "10px 12px",
          border: "1px solid #dadce0",
          borderRadius: "6px",
          backgroundColor: "#fff",
          fontSize: "14px",
          fontFamily: "Roboto, sans-serif",
          outline: "none",
          transition: "border-color 0.2s, box-shadow 0.2s",

          "&:focus": {
            borderColor: "#4285f4",
            boxShadow: "0 0 0 2px rgba(66, 133, 244, 0.15)",
          },

          "&::placeholder": {
            color: "#9aa0a6",
          },
        }}
      />
    </Box>
  );
}

export default Input;