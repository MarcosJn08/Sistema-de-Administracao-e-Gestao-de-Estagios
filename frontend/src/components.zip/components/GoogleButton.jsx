import React from "react";
import Box from "@mui/material/Box";

const GoogleButton = ({ onClick }) => {
  return (
    <Box
      component="button"
      onClick={onClick}
      sx={{
        borderRadius: "6px",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: "10px 20px",
        border: "1px solid #dadce0",
        backgroundColor: "white",
        cursor: "pointer",
        fontFamily: "Roboto, sans-serif",
        fontWeight: 500,
        color: "#3c4043",
        transition: "background-color 0.2s",

        "&:hover": {
          backgroundColor: "#f7f8f8",
          boxShadow: "0 1px 3px rgba(0,0,0,0.1)",
        },
      }}
    >
      <Box
        component="img"
        src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg"
        alt="Google logo"
        sx={{
          width: "20px",
          height: "20px",
          marginRight: "12px",
        }}
      />

      <span>Entrar com Google</span>
    </Box>
  );
};

export default GoogleButton;

